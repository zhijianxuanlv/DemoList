//
//  AppDelegate.h
//  DevDiv_UIRefreshControl
//
//  Created by BeyondVincent on 12-6-15.
//  Copyright (c) 2012年 DevDiv. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UIRefreshControl_VC;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UIRefreshControl_VC *viewController;

@end
