//
//  UIRefreshControl_VC.h
//  DevDiv_UIRefreshControl
//
//  Created by BeyondVincent on 12-6-15.
//  Copyright (c) 2012年 DevDiv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIRefreshControl_VC : UITableViewController
@property (nonatomic) NSInteger count;

@end
