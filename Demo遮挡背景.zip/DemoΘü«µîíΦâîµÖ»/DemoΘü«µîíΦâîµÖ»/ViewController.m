//
//  ViewController.m
//  Demo遮挡背景
//
//  Created by 罗成 on 15/2/3.
//  Copyright (c) 2015年 罗成. All rights reserved.
//
#define RGBColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define kWitterViewHeight 160.0
#import "ViewController.h"
#import "TwitterView.h"
@interface ViewController ()<UITextViewDelegate>{

    TwitterView *view;

}

/** 遮罩背景 */
@property (nonatomic, weak) UIButton *backButton;
/**  */
@property (nonatomic, weak) TwitterView *twitter;
- (IBAction)ButtonClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    view = [[TwitterView alloc]init];
    CGFloat viewW = [UIScreen mainScreen].bounds.size.width;
    view.frame = CGRectMake(30, 128, viewW - 55, kWitterViewHeight);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonClick:(id)sender {
    
    UIButton *button = [[UIButton alloc] init];
    button.frame = self.view.bounds;
    button.alpha = 0.5;
    [button setBackgroundColor:[UIColor blackColor]];
    [button addTarget:self action:@selector(hidenTwitter:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:button];
    self.backButton = button;
    view.hidden = NO;
    
    self.twitter = view;
    self.twitter.textView.delegate = self;
    
    //动画效果
    [UIView animateWithDuration:0.3f animations:^{
        
        self.twitter.transform = CGAffineTransformMakeTranslation(0, -kWitterViewHeight + 135 );
    }];
    //自动获取键盘焦点
    [self.twitter.textView becomeFirstResponder];
    
    
    

    self.twitter.layer.cornerRadius = 5.0;
    self.twitter.layer.masksToBounds = YES;
    [self.view addSubview:self.twitter];


}


-(void)hidenTwitter:(BOOL)animated{
    
    [UIView animateWithDuration:0.25f animations:^{
        self.backButton.alpha = 0;
        self.twitter.hidden = YES;
        [self.twitter.textView resignFirstResponder];
        self.twitter.transform = CGAffineTransformMakeTranslation(0, -kWitterViewHeight + 135 );
    }];
}



- (void)hideMenu
{
    [self hideMenu:YES];
    
    
}
- (void)hideMenu:(BOOL)animated
{
    [UIView animateWithDuration:animated ? 0.25f : 0.0f animations:^{
        self.backButton.alpha = 0;
    }];
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([text isEqualToString:@"\n"]) {
        
        [textView resignFirstResponder];
        [self hidenTwitter:YES];
        return NO;
    }
    return YES;
}

@end
