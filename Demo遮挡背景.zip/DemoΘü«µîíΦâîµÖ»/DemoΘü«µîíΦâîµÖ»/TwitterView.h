//
//  TwitterView.h
//  Demo遮挡背景
//
//  Created by 罗成 on 15/2/3.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwitterView : UIView

@property (nonatomic, weak) UITextView *textView;
@end
