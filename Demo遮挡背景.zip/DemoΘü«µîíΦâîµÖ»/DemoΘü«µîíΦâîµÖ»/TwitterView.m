//
//  TwitterView.m
//  Demo遮挡背景
//
//  Created by 罗成 on 15/2/3.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "TwitterView.h"
@interface TwitterView ()
@property (nonatomic, weak) UIView *backgroundView;
@end
@implementation TwitterView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 5.0;
        UIView *backgroundView = [[UIView alloc]init];
        backgroundView.backgroundColor = [UIColor whiteColor];
        backgroundView.alpha = 1.0;
        [self addSubview:backgroundView];
        self.backgroundView = backgroundView;
        //说说内容
        UITextView *textView = [[UITextView alloc]init];
        //设置字体
        textView.font = [UIFont systemFontOfSize:14];
        [self addSubview:textView];
        self.textView = textView;
    }

    return  self;

}

- (void)layoutSubviews {
    
    self.textView.frame = self.bounds;




}
@end
