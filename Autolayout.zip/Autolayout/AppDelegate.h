//
//  AppDelegate.h
//  Autolayout
//
//  Created by 金 聖輝 on 12-9-25.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
