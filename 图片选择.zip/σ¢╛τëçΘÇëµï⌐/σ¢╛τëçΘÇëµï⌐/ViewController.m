//
//  ViewController.m
//  图片选择
//
//  Created by 罗成 on 15/5/11.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "ViewController.h"
#import "ImageViewController.h"
#define marginX 16
#define marginY 100

@interface ViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate,ImageViewControllerDelegate>{


}



//- (IBAction)delegateImage:(id)sender;

//@property (weak, nonatomic) IBOutlet UIButton *addBtn;
//- (IBAction)addBtnClick:(id)sender;
@property (strong, nonatomic) UIActionSheet *actionSheet;
@property (strong, nonatomic) NSMutableArray *dataArray;
@property (strong, nonatomic) UIImageView *imageView;
@property (strong, nonatomic) UIButton *addBtn;
@property (strong, nonatomic) UIButton *imageBtn;

@end

@implementation ViewController

- (NSMutableArray *)dataArray {

    if (_dataArray == nil) {
        _dataArray = [NSMutableArray array];
        
    }

    return _dataArray;

}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    addBtn.frame = CGRectMake(10, 100, 67, 70);
    [addBtn setBackgroundImage:[UIImage imageNamed:@"compose_pic_add"] forState:UIControlStateNormal];
    [addBtn setBackgroundImage:[UIImage imageNamed:@"compose_pic_add_highlighted"] forState:UIControlStateHighlighted];
    [addBtn addTarget:self action:@selector(addBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    self.addBtn = addBtn;
    [self.view addSubview:addBtn];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addBtnClick:(id)sender {
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"从相册中选取", nil];
        self.actionSheet = actionSheet;
        
        
    }else {
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从相册中选取", nil];
        
        NSLog(@"%ld",actionSheet.destructiveButtonIndex);
        self.actionSheet = actionSheet;
        
        
    }
    [self.actionSheet showInView:self.view];
}

#pragma mark actionDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSInteger sourceType = 0;
    //判断是否支持相机
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        switch (buttonIndex) {
            case 0:
                //调用相册
                sourceType = UIImagePickerControllerSourceTypeCamera;
                break;
            case 1:
                //调用相机
                
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                
                break;
            case 2:
                return;
                
                break;
            default:
                break;
        }
    }else {
        
        return;
    }
    //跳转到相机活着相册页面
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    pickerController.delegate = self;
    pickerController.allowsEditing = YES;
    pickerController.sourceType = sourceType;
    [self presentViewController:pickerController animated:YES completion:nil];
    
}

#pragma mark image picker delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [self saveImage:image];
}

- (void) saveImage:(UIImage *)image {
        CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
        CGFloat imageW = self.addBtn.frame.size.width;
        CGFloat imageH = self.addBtn.frame.size.height;
        int maxColumns = screenW / imageW; // 一行最多显示4张图片
        [self.dataArray addObject:image];
        for (int i = 0; i < self.dataArray.count; i ++) {
        UIImage *image = self.dataArray[i];

        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        btn.tag = i;
        btn.frame = CGRectMake(((i % maxColumns) * imageW) + marginX , (i / maxColumns) *imageH +marginY, imageW, imageH);
//        btn.frame = CGRectMake(0, 0, imageW, imageH);
        btn.tag = i;

        [btn addTarget:self action:@selector(clickImage:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        self.addBtn.frame = CGRectMake(((i +1) % maxColumns) * imageW + marginX, ((i +1) / maxColumns) *imageH + marginY  , imageW, imageH);
                
   
        [self.view addSubview:self.addBtn];
    }



}

- (void)clickImage:(UIButton *)btn {
    ImageViewController *imageController = [[ImageViewController alloc]init];
    imageController.image = btn.currentBackgroundImage;
    imageController.delegate = self;
    [self.navigationController pushViewController:imageController animated:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

//重新计算btn位置
- (void)deleteImage:(UIImage *)image {
    [self.dataArray removeObject:image];
    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat imageW = self.addBtn.frame.size.width;
    CGFloat imageH = self.addBtn.frame.size.height;
    int maxColumns = screenW / imageW;
    for (UIView *view in self.view.subviews) {
        [view removeFromSuperview];
    }
    if (self.dataArray.count != 0) {
        for (int i = 0; i < self.dataArray.count ; i ++) {
            
            UIImage *image = self.dataArray [i];
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setBackgroundImage:image forState:UIControlStateNormal];
            btn.tag = i;
            btn.frame = CGRectMake(((i % maxColumns) * imageW) + marginX , (i / maxColumns) *imageH +marginY, imageW, imageH);
            
            [btn addTarget:self action:@selector(clickImage:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
            self.addBtn.frame = CGRectMake(((i +1) % maxColumns) * imageW + marginX, ((i + 1) / maxColumns) *imageH + marginY  , imageW, imageH);
        }
    }else {
    
        self.addBtn.frame = CGRectMake(10, 100, 67, 70);
    }

        [self.view addSubview:self.addBtn];
    

}





@end
