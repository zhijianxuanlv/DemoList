//
//  ImageViewController.m
//  图片选择
//
//  Created by 罗成 on 15/5/12.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "ImageViewController.h"

@interface ImageViewController ()

@end

@implementation ImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *imageView =  [[UIImageView alloc] initWithFrame:self.view.bounds];
    imageView.image = self.image;
    
    [self.view addSubview:imageView];
    
    UIBarButtonItem *right = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:self action:@selector(deleteImage)];
    self.navigationItem.rightBarButtonItem = right;
}

- (void)deleteImage {
    
//    for (UIImageView *imageView in self.view.subviews) {
//        if ([self.delegate respondsToSelector:@selector(imageViewWithTag:)]) {
//             [self.delegate imageViewWithTag:imageView.tag];
//            NSLog(@"%ld",imageView.tag);
//        }
//    }

    if ([self.delegate respondsToSelector:@selector(deleteImage:)]){
        [self.delegate deleteImage:self.image];
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
