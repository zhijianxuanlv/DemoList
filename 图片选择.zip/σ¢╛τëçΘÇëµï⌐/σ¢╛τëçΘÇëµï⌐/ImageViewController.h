//
//  ImageViewController.h
//  图片选择
//
//  Created by 罗成 on 15/5/12.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ImageViewControllerDelegate <NSObject>

- (void)deleteImage:(UIImage *)image;

@end
@interface ImageViewController : UIViewController
@property (strong, nonatomic) UIImage *image;
@property (weak, nonatomic) id<ImageViewControllerDelegate> delegate;
@end
