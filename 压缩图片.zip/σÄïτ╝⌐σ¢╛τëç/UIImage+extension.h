//
//  UIImage+extension.h
//  压缩图片
//
//  Created by 罗成 on 15/4/21.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (extension)
//压缩图片质量
+(UIImage *)reduceImage:(UIImage *)image percent:(float)percent;
//压缩图片尺寸
+(UIImage *)imageWithImageSimple:(UIImage *)image scaledToSize:(CGSize)newSize;
//等比例压缩
+(UIImage *) imageCompressForSize:(UIImage *)sourceImage targetSize:(CGSize)size;
@end
