//
//  UIImage+extension.m
//  压缩图片
//
//  Created by 罗成 on 15/4/21.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "UIImage+extension.h"


@implementation UIImage (extension)

+(UIImage *)reduceImage:(UIImage *)image percent:(float)percent{
    NSData *imageData = UIImageJPEGRepresentation(image, percent);

    UIImage *newImage = [UIImage imageWithData:imageData];
    
    
    return newImage;
}

+(UIImage *)imageWithImageSimple:(UIImage *)image scaledToSize:(CGSize)newSize{
    //创建图片内容
    UIGraphicsBeginImageContext(newSize);
    //图片大小
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    //从新的内容里获取图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //结束内容
    UIGraphicsEndImageContext();
    
    NSString *filePath = [NSHomeDirectory()stringByAppendingPathComponent:@"本地图片.png"];
   NSData *data = UIImagePNGRepresentation(image);
    [data writeToFile:filePath atomically:NO];
//   [UIImagePNGRepresentation(image) writeToFile:filePath atomically:NO];
    NSLog(@"%@",filePath);
    return newImage;
}
//等比例压缩
+(UIImage *) imageCompressForSize:(UIImage *)sourceImage targetSize:(CGSize)size {
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = size.width;
    CGFloat targetHeight = size.width;
    CGFloat scaleFactor = 0.0;
    CGFloat scaleWidth = targetWidth;
    CGFloat scaleHieght = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0, 0);
    if (CGSizeEqualToSize(imageSize, size) == NO) {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heigktFactor = targetHeight / height;
        if (widthFactor > heigktFactor) {
            scaleFactor = widthFactor;
        }else {
        
            scaleFactor = heigktFactor;
        }
        scaleWidth = width * scaleFactor;
        scaleHieght = height * scaleFactor;
        if (widthFactor > heigktFactor) {
            thumbnailPoint.y = (targetHeight - scaleHieght) * 0.5;
        }else if (widthFactor < heigktFactor) {
        
            thumbnailPoint.x = (targetWidth - scaleWidth) * 0.5;
        
        }

        
    }

    UIGraphicsBeginImageContext(size);
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width = scaleWidth;
    thumbnailRect.size.height = scaleHieght;
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if (newImage == nil) {
        NSLog(@"scale image fail");
    }
    UIGraphicsEndImageContext();
    

    return newImage;

}





@end
