//
//  ViewController.m
//  压缩图片
//
//  Created by 罗成 on 15/4/21.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+extension.h"
#import "SJAvatarBrowser.h"
@interface ViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>{

    BOOL isFullScreen;

}
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)btnClick:(id)sender;
@property (strong, nonatomic) UIActionSheet *actionSheet;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    UIImage *image = [UIImage imageNamed:@"1"];
////    UIImage *newImage = [UIImage reduceImage:image percent:0.3];
//    [UIImage imageWithImageSimple:image scaledToSize:CGSizeMake(100, 100)];
    self.imageView.contentMode = UIViewContentModeScaleAspectFill;
   
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnClick:(id)sender {
       if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
           
           UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"从相册中选取", nil];
           self.actionSheet = actionSheet;
           
           
       }else {
       
           UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从相册中选取", nil];
         
           NSLog(@"%ld",actionSheet.destructiveButtonIndex);
           self.actionSheet = actionSheet;
       
       
       }
    [self.actionSheet showInView:self.view];
    
}

#pragma mark actionDelegate 
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSInteger sourceType = 0;
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        switch (buttonIndex) {
            case 0:
                //调用相册
                sourceType = UIImagePickerControllerSourceTypeCamera;
                break;
            case 1:
                //调用相机
                
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
               
                break;
            case 2:
              return;
                
                break;
            default:
                break;
        }
    }else {
        
        return;
    
    
    }
    //跳转到相机活着相册页面
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    pickerController.delegate = self;
    pickerController.allowsEditing = YES;
    pickerController.sourceType = sourceType;
    [self presentViewController:pickerController animated:YES completion:nil];
    
}

#pragma mark image picker delegate 
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    self.imageView.image = image;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickImage)];
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:tap];
    
//    [self saveImage:image imagePath:@"currentImage.png"];
//   UIImage *newImage = [UIImage imageCompressForSize:image targetSize:CGSizeMake(100, 100)];
//    NSLog(@"%@",newImage);
//    self.imageView.image = image;
//    isFullScreen = NO;

}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {

    [self dismissViewControllerAnimated:YES completion:nil];

}

- (void)clickImage{

    [SJAvatarBrowser showImage:self.imageView];


}



- (void)saveImage:(UIImage *)image imagePath:(NSString *)imagePath
{
    
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5);
//获取沙盒目录
    NSString *filePath = [[NSHomeDirectory()stringByAppendingPathComponent:@"Documents"]stringByAppendingPathComponent:imagePath];
    [imageData writeToFile:filePath atomically:NO];


}

//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    isFullScreen = !isFullScreen;
//    UITouch *touch = [touches anyObject];
//    CGPoint touchPoint = [touch locationInView:self.view];
//    //触点的坐标
//    CGPoint imagePoint = self.imageView.frame.origin;
////    触点在imageview内 点击imageview放大 再次点击缩小
//    if (imagePoint.x <= touchPoint.x && imagePoint.x +self.imageView.frame.size.width >=touchPoint.x && imagePoint.y <=  touchPoint.y && imagePoint.y+self.imageView.frame.size.height >= touchPoint.y) {
//        //设置图片放大动画
//        [UIView beginAnimations:nil context:nil];
//        [UIView setAnimationDuration:0.5];
//        if (isFullScreen) {
//            
//            self.imageView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
//        }else {
//        
//            UIImageJPEGRepresentation(self.imageView.image, 0.5);
////            self.imageView.frame = CGRectMake(100, 100, 100, 100);
//        
//        
//        }
//        //commit 动画
//        [UIView commitAnimations];
//        
//        
//        
//        
//    }
//
//
//
//}



@end
