//
//  AppDelegate.h
//  压缩图片
//
//  Created by 罗成 on 15/4/21.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

