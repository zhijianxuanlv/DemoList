//
//  Toolbar.m
//  Tools
//
//  Created by 罗成 on 15/6/30.
//
//


#import "Toolbar.h"
@interface Toolbar()<UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIButton *btn;


@end
@implementation Toolbar


- (instancetype)initWithFrame:(CGRect)frame {

    if (self = [super initWithFrame:frame]) {
        [self setUI];
        
    }

    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {


    if (self = [super initWithCoder:aDecoder]) {
        [self setUI];
    }

    return self;
}

- (void) setUI {
    CGFloat  viewW = self.frame.size.width;
    CGFloat viewH = self.frame.size.height;
    CGFloat buttonW = 60.0f;
    CGFloat buttonH = 30.0f;
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, viewW - buttonW, viewH)];
    self.scrollView = scrollView;
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(viewW - buttonW, 0, buttonW, buttonH);
    btn.backgroundColor = [UIColor blueColor];
    
    [btn addTarget:self action:@selector(addImageView) forControlEvents:UIControlEventTouchUpInside];
    self.btn = btn;
    [self addSubview:btn];

}

- (void)layoutSubviews {
    CGFloat imageViewW = 30.0f;
    CGFloat imageViewH = 30.0f;
    CGFloat paddingX = 10.0f;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;
    self.scrollView.scrollEnabled = YES;
    [self addSubview:self.scrollView];
    for (int i = 0 ; i < self.array.count; i ++) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.frame = CGRectMake(paddingX + (i % self.array.count) * (paddingX + imageViewW), 0, imageViewW,imageViewH);
        imageView.backgroundColor = [UIColor redColor];
        imageView.layer.cornerRadius = imageViewW / 2;
        imageView.layer.masksToBounds = YES;
        
        if (self.scrollView.frame.size.width < self.scrollView.contentSize.width) {
            // 显示
            self.scrollView.contentSize = CGSizeMake(paddingX + ( self.array.count * (paddingX + imageViewW)) - (paddingX + imageViewW), imageViewH);
            // 平移
            [self.scrollView setContentOffset:CGPointMake((self.scrollView.contentSize.width - self.scrollView.frame.size.width) +(paddingX + imageViewW) , 0) animated:YES];
        }
        self.scrollView.contentSize = CGSizeMake(paddingX + (self.array.count * (paddingX + imageViewW)), imageViewH);
        [self.scrollView addSubview:imageView];
    }


}

- (void)addImageView {
    UIImageView *imageView = [[UIImageView alloc]init];
    
    [self setNeedsLayout];
    [self.array addObject:imageView];
    NSLog(@"%ld",self.subviews.count);
    NSLog(@"%ld",self.array.count);
  
}

- (NSMutableArray *)array {

    if (_array == nil) {
        _array = [[NSMutableArray alloc]init];
    }
    return _array;
}


@end
