//
//  AppDelegate.h
//  Tools
//
//  Created by 罗成 on 15/6/30.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

