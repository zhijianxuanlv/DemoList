//
//  ViewController.m
//  Tools
//
//  Created by 罗成 on 15/6/30.
//
//

#import "ViewController.h"
#import "Toolbar.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Toolbar *toolbar = [[Toolbar alloc]initWithFrame:CGRectMake(0, 100, self.view.frame.size.width , 50)];

    toolbar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:toolbar];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
