//
//  AddClientViewController.m
//  CRM
//
//  Created by 罗成 on 15/5/8.
//  Copyright (c) 2015年 罗成. All rights reserved.
//

#import "AddClientViewController.h"
#import "XLForm.h"
@interface AddClientViewController ()

@end

@implementation AddClientViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeForm];
}

- (void) initializeForm{

    XLFormDescriptor *form;
    XLFormSectionDescriptor * section;
    XLFormRowDescriptor * row;
    
    form = [XLFormDescriptor formDescriptor];
        section = [XLFormSectionDescriptor formSectionWithTitle:@"添加客户信息"];
    row = [XLFormRowDescriptor formRowDescriptorWithTag:@"buinsess" rowType: XLFormRowDescriptorTypePicker title:@"buiness"];
    
    [section addFormRow:row];
    [form addFormSection:section];
}

@end
