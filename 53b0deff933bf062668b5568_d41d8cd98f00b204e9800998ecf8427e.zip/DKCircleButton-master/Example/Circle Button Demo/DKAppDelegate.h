//
//  DKAppDelegate.h
//  Circle Button Demo
//
//  Created by Dmitry Klimkin on 3/5/14.
//  Copyright (c) 2014 Dmitry Klimkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
